'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

type Part = {
  id: string;
  part_name: string | null;
  part_number: string | null;
  supplier: string | null;
  quantity: number | null;
  notes: string | null;
  machines?: { name: string } | null;
};

export default function Parts() {
  const [parts, setParts] = useState<Part[]>([]);

  useEffect(() => {
    loadParts();
  }, []);

  async function loadParts() {
    const { data } = await supabase
      .from('parts')
      .select('id,part_name,part_number,supplier,quantity,notes,machines(name)')
      .order('created_at', { ascending: false })
      .limit(50);
    setParts((data || []) as Part[]);
  }

  return (
    <main>
      <h1>Parts</h1>
      <div className="card">
        <h2>Scanned / Saved Parts</h2>
        {parts.length === 0 && <p className="muted">No parts saved yet. Scan a machine tag with a part number first.</p>}
        {parts.map(p => (
          <div className="row" key={p.id}>
            <div>
              <b>{p.part_name || 'Unnamed part'}</b>
              <p className="muted">Part #: {p.part_number || 'unknown'} · Machine: {p.machines?.name || 'not linked'} · Qty: {p.quantity || 1}</p>
              {p.notes && <p>{p.notes}</p>}
            </div>
            <span>{p.supplier || 'No supplier'}</span>
          </div>
        ))}
      </div>
    </main>
  );
}
