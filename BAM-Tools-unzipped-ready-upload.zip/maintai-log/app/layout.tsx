import './globals.css';
import Link from 'next/link';
export const metadata={title:'MaintAI Log',description:'AI maintenance knowledge base'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><div className="wrap"><nav className="card"><b>MaintAI Log</b> · <Link href="/">Dashboard</Link> · <Link href="/machines">Machines</Link> · <Link href="/repairs">Repairs</Link> · <Link href="/parts">Parts</Link></nav>{children}</div></body></html>}
