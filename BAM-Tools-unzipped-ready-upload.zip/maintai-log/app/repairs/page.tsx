'use client';
import {useState} from 'react';
import {supabase} from '@/lib/supabaseClient';
export default function Repairs(){const [form,setForm]=useState({machine_name:'',problem:'',cause:'',solution:'',downtime_minutes:'',parts_used:''});const [status,setStatus]=useState('');
function set(k:string,v:string){setForm({...form,[k]:v})}
async function save(){const {error}=await supabase.from('repairs').insert({...form,downtime_minutes:Number(form.downtime_minutes||0)});setStatus(error?error.message:'Repair saved.')}
return <main><h1>Repair Log</h1><div className="card"><input placeholder="Machine name" onChange={e=>set('machine_name',e.target.value)}/><textarea placeholder="Problem" onChange={e=>set('problem',e.target.value)}/><textarea placeholder="Cause" onChange={e=>set('cause',e.target.value)}/><textarea placeholder="Solution / fix" onChange={e=>set('solution',e.target.value)}/><input placeholder="Downtime minutes" onChange={e=>set('downtime_minutes',e.target.value)}/><textarea placeholder="Parts used" onChange={e=>set('parts_used',e.target.value)}/><button onClick={save}>Save Repair</button><p className="muted">{status}</p></div></main>}
