'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

type ScanResult = {
  manufacturer?: string | null;
  model?: string | null;
  serial_number?: string | null;
  part_number?: string | null;
  voltage?: string | null;
  hp?: string | null;
  amps?: string | null;
  rpm?: string | null;
  notes?: string | null;
  confidence?: string | null;
};

type Machine = {
  id: string;
  name: string;
  location: string | null;
  manufacturer: string | null;
  model: string | null;
  serial_number: string | null;
  image_url: string | null;
};

export default function Machines() {
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [scan, setScan] = useState<ScanResult | null>(null);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [status, setStatus] = useState('');

  useEffect(() => {
    loadMachines();
  }, []);

  async function loadMachines() {
    const { data } = await supabase
      .from('machines')
      .select('id,name,location,manufacturer,model,serial_number,image_url')
      .order('created_at', { ascending: false })
      .limit(20);
    setMachines((data || []) as Machine[]);
  }

  async function uploadPhoto(machineId: string) {
    if (!file) return null;
    const ext = file.name.split('.').pop() || 'jpg';
    const path = `${machineId}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from('machine-photos').upload(path, file, { upsert: true });
    if (error) throw error;
    const { data } = supabase.storage.from('machine-photos').getPublicUrl(path);
    return data.publicUrl;
  }

  async function aiScan() {
    if (!file) {
      setStatus('Choose a photo first.');
      return;
    }
    setStatus('Scanning photo with AI...');
    const fd = new FormData();
    fd.append('image', file);
    const res = await fetch('/api/ai-scan', { method: 'POST', body: fd });
    const data = await res.json();
    if (!res.ok) {
      setStatus(data.error || 'AI scan failed.');
      return;
    }
    setScan(data);
    setStatus('AI scan complete. Review it, then save.');
  }

  async function saveMachine() {
    if (!name.trim()) {
      setStatus('Machine name is required.');
      return;
    }
    try {
      setStatus('Saving machine...');
      const { data, error } = await supabase
        .from('machines')
        .insert({
          name,
          location,
          notes,
          manufacturer: scan?.manufacturer,
          model: scan?.model,
          serial_number: scan?.serial_number,
          voltage: scan?.voltage,
          hp: scan?.hp,
          amps: scan?.amps,
          rpm: scan?.rpm,
          ai_scan_json: scan || null
        })
        .select('id')
        .single();
      if (error) throw error;

      let imageUrl = null;
      if (file) {
        imageUrl = await uploadPhoto(data.id);
        await supabase.from('machines').update({ image_url: imageUrl }).eq('id', data.id);
      }

      if (scan?.part_number) {
        await supabase.from('parts').insert({
          machine_id: data.id,
          part_name: scan.model || scan.manufacturer || 'Scanned part',
          part_number: scan.part_number,
          supplier: null,
          notes: scan.notes || null
        });
      }

      setStatus('Machine saved with AI data.');
      setName('');
      setLocation('');
      setNotes('');
      setFile(null);
      setScan(null);
      await loadMachines();
    } catch (err: any) {
      setStatus(`Error: ${err.message}`);
    }
  }

  return (
    <main>
      <h1>Machines</h1>
      <div className="card">
        <h2>Add Machine + AI Scan</h2>
        <input placeholder="Machine name, ex: Extruder 3" value={name} onChange={e => setName(e.target.value)} />
        <input placeholder="Location, ex: Line 2" value={location} onChange={e => setLocation(e.target.value)} />
        <textarea placeholder="Notes" value={notes} onChange={e => setNotes(e.target.value)} />
        <input type="file" accept="image/*" onChange={e => setFile(e.target.files?.[0] || null)} />
        <button onClick={aiScan}>AI Scan Equipment Tag</button>
        <button onClick={saveMachine}>Save Machine</button>
        <p className="muted">{status}</p>
      </div>

      {scan && (
        <div className="card">
          <h2>AI Extracted Data</h2>
          {Object.entries(scan).map(([k, v]) => <span className="pill" key={k}>{k}: {String(v)}</span>)}
        </div>
      )}

      <div className="card">
        <h2>Recent Machines</h2>
        {machines.length === 0 && <p className="muted">No machines saved yet.</p>}
        {machines.map(m => (
          <div className="row" key={m.id}>
            <div>
              <b>{m.name}</b>
              <p className="muted">{m.location || 'No location'} · {m.manufacturer || 'Unknown'} {m.model || ''} · S/N {m.serial_number || 'unknown'}</p>
            </div>
            {m.image_url && <a href={m.image_url} target="_blank">Photo</a>}
          </div>
        ))}
      </div>
    </main>
  );
}
