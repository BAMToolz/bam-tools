import OpenAI from 'openai';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const image = form.get('image') as File | null;
    if (!image) return NextResponse.json({ error: 'No image uploaded' }, { status: 400 });

    const bytes = Buffer.from(await image.arrayBuffer());
    const base64 = bytes.toString('base64');
    const dataUrl = `data:${image.type};base64,${base64}`;

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: 'gpt-4.1-mini',
      input: [{
        role: 'user',
        content: [
          { type: 'input_text', text: 'Extract industrial equipment tag data. Return ONLY valid JSON with keys: manufacturer, model, serial_number, part_number, voltage, hp, amps, rpm, notes, confidence. Use null when unknown.' },
          { type: 'input_image', image_url: dataUrl }
        ]
      }]
    });

    const text = response.output_text || '{}';
    const cleaned = text.replace(/```json|```/g, '').trim();
    return NextResponse.json(JSON.parse(cleaned));
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'AI scan failed' }, { status: 500 });
  }
}
