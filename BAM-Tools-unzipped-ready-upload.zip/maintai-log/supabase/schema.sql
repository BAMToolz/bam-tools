create extension if not exists pgcrypto;

create table if not exists machines (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  name text not null,
  location text,
  manufacturer text,
  model text,
  serial_number text,
  voltage text,
  hp text,
  amps text,
  rpm text,
  image_url text,
  ai_scan_json jsonb,
  notes text
);

create table if not exists parts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  machine_id uuid references machines(id) on delete set null,
  part_name text,
  part_number text,
  supplier text,
  quantity integer default 1,
  notes text
);

create table if not exists repairs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  machine_id uuid references machines(id) on delete set null,
  machine_name text,
  problem text not null,
  cause text,
  solution text,
  downtime_minutes integer default 0,
  parts_used text
);

-- Supabase Storage setup for machine photos.
-- In Supabase dashboard, create a PUBLIC bucket named: machine-photos
-- For MVP testing only, use open policies below. Lock this down before production.

do $$
begin
  if not exists (
    select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname = 'public machine photo read'
  ) then
    create policy "public machine photo read"
    on storage.objects for select
    using (bucket_id = 'machine-photos');
  end if;
end $$;

do $$
begin
  if not exists (
    select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname = 'public machine photo upload'
  ) then
    create policy "public machine photo upload"
    on storage.objects for insert
    with check (bucket_id = 'machine-photos');
  end if;
end $$;
