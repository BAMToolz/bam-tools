# MaintAI Log

AI-powered manufacturing maintenance web app starter.

## What this build has now
- Machine profiles
- Repair logs
- Parts page
- AI equipment tag scan from uploaded photos
- Saves uploaded machine photo to Supabase Storage
- Saves AI extracted data into the machine record
- Automatically creates a parts record when AI finds a part number

## Setup
1. Install Node.js LTS.
2. Create a Supabase project.
3. In Supabase SQL Editor, run `supabase/schema.sql`.
4. In Supabase Storage, create a public bucket named `machine-photos`.
5. Copy `.env.example` to `.env.local` and fill in keys.
6. Run:

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Environment variables
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `OPENAI_API_KEY`

## First field test
1. Add a machine name like `Extruder 1`.
2. Upload a motor plate, drive label, gearbox tag, or control component label.
3. Click `AI Scan Equipment Tag`.
4. Review extracted data.
5. Click `Save Machine`.
6. Check `Parts` to see if a part number was saved.

## Production warning
The starter uses public storage/upload policies for fast MVP testing. Before this becomes a real business app, add login, company accounts, and locked-down storage rules.
