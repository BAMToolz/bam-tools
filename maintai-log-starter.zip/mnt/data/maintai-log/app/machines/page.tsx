'use client';
import {useState} from 'react';
import {supabase} from '@/lib/supabaseClient';

type ScanResult={manufacturer?:string;model?:string;serial_number?:string;part_number?:string;voltage?:string;hp?:string;amps?:string;notes?:string;confidence?:string};
export default function Machines(){
 const [name,setName]=useState(''); const [location,setLocation]=useState(''); const [notes,setNotes]=useState('');
 const [file,setFile]=useState<File|null>(null); const [scan,setScan]=useState<ScanResult|null>(null); const [status,setStatus]=useState('');
 async function aiScan(){ if(!file){setStatus('Choose a photo first.');return} setStatus('Scanning photo with AI...');
  const fd=new FormData(); fd.append('image',file); const res=await fetch('/api/ai-scan',{method:'POST',body:fd}); const data=await res.json(); setScan(data); setStatus('AI scan complete.'); }
 async function saveMachine(){ setStatus('Saving machine...');
  const {error}=await supabase.from('machines').insert({name,location,notes,manufacturer:scan?.manufacturer,model:scan?.model,serial_number:scan?.serial_number});
  setStatus(error?`Error: ${error.message}`:'Machine saved.'); }
 return <main><h1>Machines</h1><div className="card"><h2>Add Machine</h2><input placeholder="Machine name, ex: Extruder 3" value={name} onChange={e=>setName(e.target.value)}/><input placeholder="Location" value={location} onChange={e=>setLocation(e.target.value)}/><textarea placeholder="Notes" value={notes} onChange={e=>setNotes(e.target.value)}/><input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0]||null)}/><button onClick={aiScan}>AI Scan Equipment Tag</button><button onClick={saveMachine}>Save Machine</button><p className="muted">{status}</p></div>{scan&&<div className="card"><h2>AI Extracted Data</h2>{Object.entries(scan).map(([k,v])=><span className="pill" key={k}>{k}: {String(v)}</span>)}</div>}</main> }
