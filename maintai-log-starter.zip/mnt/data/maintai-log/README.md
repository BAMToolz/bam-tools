# MaintAI Log

AI-powered manufacturing maintenance web app starter.

## Features in this starter
- Machine profiles
- Repair logs
- AI equipment tag scan from uploaded photos
- Supabase database schema

## Setup
1. Install Node.js.
2. Create a Supabase project.
3. Run `supabase/schema.sql` in Supabase SQL editor.
4. Copy `.env.example` to `.env.local` and fill in keys.
5. Run:

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Environment variables
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY
- OPENAI_API_KEY

## Next build step
Add Supabase Storage bucket named `machine-photos`, save uploaded images, then connect scan results to parts and machines.
