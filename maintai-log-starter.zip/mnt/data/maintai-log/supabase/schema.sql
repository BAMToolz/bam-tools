create table if not exists machines (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  name text not null,
  location text,
  manufacturer text,
  model text,
  serial_number text,
  notes text
);

create table if not exists parts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  machine_id uuid references machines(id) on delete set null,
  part_name text,
  part_number text,
  supplier text,
  quantity integer default 1,
  notes text
);

create table if not exists repairs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  machine_id uuid references machines(id) on delete set null,
  machine_name text,
  problem text not null,
  cause text,
  solution text,
  downtime_minutes integer default 0,
  parts_used text
);
