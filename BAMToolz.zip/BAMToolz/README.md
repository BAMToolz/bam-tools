# BAMToolz

Ball Advanced Maintenance Tools — AI-powered maintenance and downtime support for manufacturing.

## Upload to GitHub from iPhone

1. Open your GitHub repository.
2. Tap **Add file**.
3. Tap **Upload files**.
4. Upload every file/folder from this ZIP.
5. Commit changes.
6. Go to Vercel and import the GitHub repo.

## Local commands

```bash
npm install
npm run dev
```
