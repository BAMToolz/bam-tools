export default function Home() {
  return (
    <main className="page">
      <section className="hero">
        <div className="badge">Ball Advanced Maintenance Tools</div>
        <h1>BAMToolz</h1>
        <p className="tagline">
          AI-powered maintenance tools for manufacturing downtime, equipment logs,
          parts lists, manuals, troubleshooting, and controls documentation.
        </p>
        <div className="actions">
          <a href="mailto:info@bamtoolz.com" className="button primary">Contact</a>
          <a href="#features" className="button secondary">See Features</a>
        </div>
      </section>

      <section id="features" className="cards">
        <div className="card">
          <h2>Equipment Photo Scan</h2>
          <p>Capture machine tags, logs, and labels to organize asset information faster.</p>
        </div>
        <div className="card">
          <h2>Spare Parts Lists</h2>
          <p>Build machine-based parts lists from logs, manuals, and technician notes.</p>
        </div>
        <div className="card">
          <h2>Downtime Tracking</h2>
          <p>Track failures, repairs, root causes, and repeat problems by machine.</p>
        </div>
        <div className="card">
          <h2>Controls Support</h2>
          <p>Organize PLC I/O, wiring notes, panel documentation, and troubleshooting steps.</p>
        </div>
      </section>
    </main>
  );
}
