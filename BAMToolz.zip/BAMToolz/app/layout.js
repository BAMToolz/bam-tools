import './globals.css';

export const metadata = {
  title: 'BAMToolz',
  description: 'Ball Advanced Maintenance Tools - AI-powered maintenance and downtime support.'
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
